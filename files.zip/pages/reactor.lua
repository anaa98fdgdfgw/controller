-- Page 5 : contrôle Big Reactor
local M = {}

function M.draw()
    -- TODO: Affichage et gestion du contrôle du reactor
end

function M.handleClick(x, y)
    -- TODO: Gestion des clics sur la page Reactor
end

return M