-- Page 4 : analyse turtle en direct + détails
local M = {}

function M.draw()
    -- TODO: Affichage liste turtles, minimap, détails d'une turtle
end

function M.handleClick(x, y)
    -- TODO: Gestion des clics sur la page Analyse Turtle
end

return M