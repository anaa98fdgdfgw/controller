-- Page 1 : dashboard ON/OFF usines
local M = {}

function M.draw()
    -- TODO: Affichage et gestion du dashboard usines
end

function M.handleClick(x, y)
    -- TODO: Gestion des clics sur la page Dashboard
end

return M