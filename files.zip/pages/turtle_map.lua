-- Page 3 : map & contrôle turtle agricole
local M = {}

function M.draw()
    -- TODO: Affichage carte, gestion ajout de champs, association turtles, etc.
end

function M.handleClick(x, y)
    -- TODO: Gestion des clics sur la page Map Turtle
end

return M