-- Page 2 : liste autocraft AE2
local M = {}

function M.draw()
    -- TODO: Affichage et gestion liste des patterns AE2
end

function M.handleClick(x, y)
    -- TODO: Gestion des clics sur la page Autocraft
end

return M