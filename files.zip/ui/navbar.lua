-- Composant : barre de navigation (affichage et gestion des clics)
local M = {}

function M.draw(currentPage, pages, keypadOpen)
    -- TODO: Affichage graphique de la barre de navigation
end

function M.handleClick(x, y)
    -- TODO: Gérer les clics sur la barre
end

return M