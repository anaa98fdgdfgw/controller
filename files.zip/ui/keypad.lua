-- Composant : keypad numérique ouvrable/fermé
local M = {}

function M.draw(open)
    -- TODO: Affichage graphique du keypad si 'open' est true
end

function M.handleClick(x, y)
    -- TODO: Gérer les clics sur le keypad
end

return M