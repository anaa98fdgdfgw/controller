-- Synchronisation pocket <-> PC central
local M = {}

function M.send(data)
    -- TODO: Envoyer data au PC central ou pocket
end

function M.receive()
    -- TODO: Recevoir data (événement réseau)
end

return M